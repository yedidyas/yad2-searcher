module.exports.searchData = [
    {
        name: 'ראשון לציון אברמוביץ',
        city: '8300',
        neighborhood: '287'
    },
    {
        name: 'ראשון לציון כצנלסון',
        city: '8300',
        neighborhood: '288'
    },
    {
        name: 'ראשון לציון ראשונים',
        city: '8300',
        neighborhood: '326'
    },
    {
        name: 'ראשון לציון רמז מערב ותיק',
        city: '8300',
        neighborhood: '289'
    },
    {
        name: 'בת ים לב העיר',
        city: '6200',
        neighborhood: '991410'
    },
    {
        name: 'בת ים דרום מערב ותיק',
        city: '6200',
        neighborhood: '991406'
    },
    {
        name: 'בת ים רוטשילד עצמאות',
        city: '6200',
        neighborhood: '1403'
    },
    {
        name: 'בת ים עצמאות יוספטל',
        city: '6200',
        neighborhood: '991409'
    },
    {
        name: 'בת ים ותיקים',
        city: '6200',
        neighborhood: '1527'
    },
    {
        name: 'רחובות שכונה א',
        city: '8400',
        neighborhood: '20060001'
    },
    {
        name: 'רחובות שכונה ב',
        city: '8400',
        neighborhood: '20060009'
    },
    {
        name: 'רחובות המדע',
        city: '8400',
        neighborhood: '1234'
    },
];

