# Purpose

automatic yad2 searcher
